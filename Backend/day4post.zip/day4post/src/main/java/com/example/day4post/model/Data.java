package com.example.day4post.model;

public @interface Data {

}
