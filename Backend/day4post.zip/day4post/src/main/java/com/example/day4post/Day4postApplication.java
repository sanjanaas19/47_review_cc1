package com.example.day4post;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day4postApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day4postApplication.class, args);
	}

}
