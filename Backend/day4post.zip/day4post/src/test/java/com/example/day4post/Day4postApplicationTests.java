package com.example.day4post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day4postApplicationTests {

	@Test
	void contextLoads() {
	}

}
